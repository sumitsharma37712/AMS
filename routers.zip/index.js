const express=require('express')
const serverless=require('serverless-http')
const app=new express()
const conn=require('./database/config')
const port=process.env.port || 4000;
const host="localhost"
const router=require('./routers/route')
const employee=require('./database/models/admin/register_emp')
const Employeeatten=require('./database/models/employee/atten')





const cors=require('cors')
app.use(express.json())
app.use(router)
app.use(cors())


// app.listen(port,()=>{
//     console.log(`server port start ${port}`)
// })

app.use('./netlify/functions/api',router)
module.exports.handler=serverless(app)