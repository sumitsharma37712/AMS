const mongoose=require('mongoose')
// const validator=require('validator')
mongoose.connect('mongodb://127.0.0.1:27017/AMS',{ useNewUrlParser: true }, { useUndefinedTopology: true }).then(() => {
    console.log('successful connect')
}).catch((err) => { console.log(err) });